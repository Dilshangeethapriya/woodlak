<?php

$conn = mysqli_connect('localhost', 'root', '', 'woodlak') or die('connection failed');

?>